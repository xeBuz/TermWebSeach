### setup.py ###
from distutils.core import setup

setup (name='TermWebSearch',
      version='0.1a',
      description='Buscador de terminos',
      author='Jesus Roldan',
      author_email='jesus.roldan@gmail.com',
      url='http://jesusroldan.com',
      license='GPLv3',
      py_modules=['termwebsearch']
)
